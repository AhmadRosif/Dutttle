# donat
spining donut with three js [demo](https://ka-shifuka.github.io/donat/)
